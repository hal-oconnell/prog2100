//
// Created by prog2100 on 04/10/17.
//

#ifndef MINHERITOR_2_MAMMAL_H
#define MINHERITOR_2_MAMMAL_H
#include <iostream>
using namespace std;

class Mammal
	{
	public:
		string warmblood;

		Mammal();
		~Mammal();
		void stayWarm();

	};


#endif //MINHERITOR_2_MAMMAL_H
