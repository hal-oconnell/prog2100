//
// Created by prog2100 on 04/10/17.
//
#include <iostream>
#include "cat.h"

// Cat class is derived from base class Animal.

void Cat::aboutMeow() { cout << "I can Meow." << endl; }
