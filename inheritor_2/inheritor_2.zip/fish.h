//
// Created by prog2100 on 04/10/17.
//

#ifndef INHERITOR_2_FISH_H
#define INHERITOR_2_FISH_H

#include "animal.h"

// Fish class is derived from base class Animal.
class Fish : public Animal
{
public:
	void aboutSplash();
};
#endif //INHERITOR_2_FISH_H
