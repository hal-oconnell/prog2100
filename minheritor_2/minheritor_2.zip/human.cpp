//
// Created by prog2100 on 04/10/17.
//
#include "animal.h"

#include "human.h"

void Human::aboutUs() { cout << "I have opposable thumbs" << endl; }

