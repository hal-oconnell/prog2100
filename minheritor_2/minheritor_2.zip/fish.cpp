//
// Created by prog2100 on 04/10/17.
//

#include "fish.h"


// Fish class is derived from base class Animal.
void Fish::aboutSplash() { cout << "I can splash and swim." << endl; }
