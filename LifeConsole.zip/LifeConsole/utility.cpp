//
//  utility.cpp
//
//  Created by Hal O'Connell on 2012-10-18.
//  Copyright (c) 2012 Hal O'Connell. All rights reserved.
//
// Add any need utility routines to this class

#include <iostream>


#include <string.h>
#include <ctype.h>
#include <time.h>

#include "utility.h"

using namespace std;
